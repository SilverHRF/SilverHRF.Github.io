module RBS
  module Test
  end
end
