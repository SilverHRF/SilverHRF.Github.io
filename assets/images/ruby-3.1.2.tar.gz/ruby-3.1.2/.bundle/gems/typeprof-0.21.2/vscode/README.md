# Ruby TypeProf VSCode Integration

*NOTE: This extenstion is very preliminary.*

This is a VSCode extension to help you write Ruby code by using an code analyzer called [Ruby TypeProf](https://github.com/ruby/typeprof/) as a backend.

## How to use this extension

*TBD*

Requirements:

1. Use Ruby 3.1.0 or later, and TypeProf 0.20.0 or later
2. Add `gem "typeprof"` to your `Gemfile`, and execute `bundle install`

Troubleshooting:

*TBD*

## How to develop this extension

See [development.md](https://github.com/ruby/typeprof/blob/master/development.md).