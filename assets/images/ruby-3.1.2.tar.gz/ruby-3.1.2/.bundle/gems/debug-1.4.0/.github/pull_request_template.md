Thanks for your Pull Request 🎉 

**Please follow these instructions to help us review it more efficiently:**

- Add references of related issues/PRs in the description if available.
- If you're updating the readme file, make sure you followed [the instruction here](https://github.com/ruby/debug/blob/master/CONTRIBUTING.md#to-update-readme).

## Description
Describe your changes:
